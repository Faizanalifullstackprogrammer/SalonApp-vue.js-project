import { createI18n } from "vue-i18n";
import ar from '@/locales/ar';
import cn from '@/locales/cn';
import en from '@/locales/en';
import es from '@/locales/es';
import fr from '@/locales/fr';
import he from '@/locales/he';
import nl from '@/locales/nl';
import ru from '@/locales/ru';

const i18n = createI18n({
  legacy: false,
  locale: "en",
  fallbackLocale: 'en',
  messages: {
    en: en,
    ar: ar,
    es: es,
    cn: cn,
    fr: fr,
    he: he,
    nl: nl,
    ru: ru,
  }
});
export default i18n;