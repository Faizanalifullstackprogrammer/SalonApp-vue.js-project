<template>
  <div>
    <!-- share_model_wrapper -->
    <div class="share_model_wrapper">
      <div class="modal fade" id="share_model">
        <div class="modal-dialog modal-lg modal-dialog-centered">
          <div class="modal-content">
            <!-- Modal Header -->
            <div
              class="modal-header"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            >
              <h4 class="modal-title">Share</h4>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
              ></button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
              <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" data-bs-toggle="tab" href="#sms"
                    >SMS</a
                  >
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="tab" href="#email"
                    >EMAIL</a
                  >
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="tab" href="#id">ID</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="tab" href="#qr">QR</a>
                </li>
              </ul>
              <div class="tab-content">
                <div id="sms" class="container tab-pane active">
                  <form>
                    <div class="form-group">
                      <textarea
                        class="form-control"
                        placeholder="Message"
                      ></textarea>
                    </div>
                    <div class="form-group">
                      <input
                        type="tel"
                        class="form-control"
                        placeholder="Phone"
                      />
                    </div>
                    <div class="search_box">
                      <ul class="list-unstyled list-inline">
                        <li class="list-inline-item">
                          <button type="button" class="btn btn_sub">
                            Search
                          </button>
                          <button
                            type="button"
                            class="btn btn_sub search_slide"
                          >
                            ...
                          </button>
                        </li>
                      </ul>
                    </div>
                    <div class="share_via">
                      <h4>Share Via</h4>
                      <ul class="list-inline list-unstyled">
                        <li class="list-inline-item">
                          <a href="#"><i class="fa fa-copyright"></i></a>
                        </li>
                        <li class="list-inline-item">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li class="list-inline-item">
                          <a href="#"><i class="fab fa-whatsapp"></i></a>
                        </li>
                        <li class="list-inline-item">
                          <a href="#"><i class="fas fa-envelope"></i></a>
                        </li>
                      </ul>
                    </div>
                  </form>
                </div>
                <div id="email" class="container tab-pane fade">
                  <form>
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Enter Your Name"
                      />
                    </div>
                    <div class="form-group">
                      <textarea
                        class="form-control"
                        placeholder="Message"
                      ></textarea>
                    </div>
                    <div class="form-group">
                      <input
                        type="email"
                        class="form-control"
                        placeholder="Email Address"
                      />
                    </div>
                    <div class="search_box">
                      <ul class="list-unstyled list-inline">
                        <li class="list-inline-item">
                          <button type="button" class="btn btn_sub">
                            Search
                          </button>
                          <button
                            type="button"
                            class="btn btn_sub search_slide"
                          >
                            ...
                          </button>
                        </li>
                      </ul>
                    </div>
                    <div class="share_via">
                      <h4>Share Via</h4>
                      <ul class="list-inline list-unstyled">
                        <li class="list-inline-item">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li class="list-inline-item">
                          <a href="#"><i class="fab fa-whatsapp"></i></a>
                        </li>
                        <li class="list-inline-item">
                          <a href="#"><i class="fas fa-envelope"></i></a>
                        </li>
                      </ul>
                    </div>
                  </form>
                </div>
                <div id="id" class="container tab-pane fade">
                  <form>
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Prenom"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Nom"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Societe"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="tel"
                        class="form-control"
                        placeholder="Tel Mobile"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="email"
                        class="form-control"
                        placeholder="Mail"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Lieu Rencontre"
                      />
                    </div>
                    <div class="search_box">
                      <ul class="list-unstyled list-inline">
                        <li class="list-inline-item">
                          <button type="button" class="btn btn_sub">
                            Search
                          </button>
                          <button
                            type="button"
                            class="btn btn_sub search_slide"
                          >
                            X
                          </button>
                          <button
                            type="button"
                            class="btn btn_sub search_slide"
                          >
                            Record
                          </button>
                        </li>
                      </ul>
                    </div>
                    <div class="share_via">
                      <h4>Share Via</h4>
                      <ul class="list-inline list-unstyled">
                        <li class="list-inline-item">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li class="list-inline-item">
                          <a href="#"><i class="fab fa-whatsapp"></i></a>
                        </li>
                        <li class="list-inline-item">
                          <a href="#"><i class="fas fa-envelope"></i></a>
                        </li>
                      </ul>
                    </div>
                  </form>
                </div>
                <div id="qr" class="container tab-pane fade qr_code_box">
                  <div class="row">
                    <div class="col-md-7">
                      <div class="tab-content">
                        <div id="qr_v1" class="container tab-pane active">
                          <div class="ar_code">
                            <h4>Catalog With Selections</h4>
                            <img src="/images/3259672.png" alt="" />
                          </div>
                        </div>
                        <div id="qr_v2" class="container tab-pane">
                          <div class="ar_code">
                            <h4>Complete Catalog</h4>
                            <img src="/images/736140.png" alt="" />
                          </div>
                        </div>
                        <div id="qr_v3" class="container tab-pane">
                          <div class="ar_code">
                            <h4>Coordonnees</h4>
                            <img src="/images/3259672.png" alt="" />
                          </div>
                        </div>
                        <div id="qr_v4" class="container tab-pane">
                          <div class="ar_code">
                            <h4>Coordonnees</h4>
                            <img src="/images/736140.png" alt="" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-2"></div>
                    <div class="col-md-3">
                      <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                          <a
                            class="nav-link active"
                            data-bs-toggle="tab"
                            href="#qr_v1"
                            >Sel</a
                          >
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-bs-toggle="tab" href="#qr_v2"
                            >All</a
                          >
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-bs-toggle="tab" href="#qr_v3"
                            >Ident</a
                          >
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-bs-toggle="tab" href="#qr_v4"
                            >Link</a
                          >
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- share_model_wrapper end -->

    <!-- guide_model -->
    <div class="guide_model">
      <div class="modal fade" id="guide">
        <div class="modal-dialog modal-xl modal-dialog-centered">
          <div class="modal-content">
            <!-- Modal Header -->
            <div
              class="modal-header"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            >
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
              ></button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
              <div class="progress">
                <div
                  class="progress-bar progress-bar-striped active"
                  role="progressbar"
                  aria-valuemin="0"
                  aria-valuemax="100"
                  :style="{ width: progressWidth }"
                >
                  {{ progressWidth }}
                </div>
              </div>

              <div class="step well" v-if="step == 1">
                <div class="step_heading">
                  <h4>Mobislide V2.3 15/02/2021</h4>
                  <h4>cat 13/06/2019 08:28</h4>
                  <div class="mid_head">
                    <p>Lorem Ipsum is simply dummy text</p>
                    <p>Lorem Ipsum is simply dummy text</p>

                    <ul class="list-unstyled list-inline">
                      <li>
                        Lorem Ipsum is
                        <i class="fas fa-arrow-alt-right"></i> Lorem Ipsum i
                      </li>
                      <li>
                        Lorem Ipsum is
                        <i class="fas fa-arrow-alt-left"></i> Lorem Ipsum i
                      </li>
                      <li>Lorem Ipsum is <span>Farmer</span> Lorem Ipsum i</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="step well" v-if="step == 2">
                <div class="row">
                  <div class="col-md-6">
                    <div class="desc">
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua. Ut enim ad minim veniam, quis
                        nostrud exercitation ullamco laboris nisi ut aliquip ex
                        ea commodo consequat. Duis aute irure dolor in
                        reprehenderit in voluptate velit esse cillum dolore eu
                        fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit
                        anim id est laborum.
                      </p>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="thumb">
                      <img src="/images/banner.jpg" class="img-fluid" alt="" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="step well" v-if="step == 3">
                <div class="row">
                  <div class="col-md-6">
                    <div class="desc">
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua. Ut enim ad minim veniam, quis
                        nostrud exercitation ullamco laboris nisi ut aliquip..
                      </p>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="thumb">
                      <img
                        src="/images/lesalon_banner.jpg"
                        class="img-fluid"
                        alt=""
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div class="step well" v-if="step == 4">
                <div class="row">
                  <div class="col-md-6">
                    <div class="desc">
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua. Ut enim ad minim veniam, quis
                        nostrud exercitation ullamco laboris nisi ut aliquip..
                      </p>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="thumb">
                      <img
                        src="/images/design_v3.jpg"
                        class="img-fluid"
                        alt=""
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div class="back_nxt">
                <ul class="list-unstyled list-inline">
                  <li class="list-inline-item"><a href="#">Farmer</a></li>
                  <li class="list-inline-item">
                    <button
                      class="action back"
                      v-if="step != 1"
                      @click="backBtn"
                    >
                      <i class="fas fa-arrow-alt-left"></i>
                    </button>
                  </li>
                  <li class="list-inline-item">
                    <button
                      class="action next"
                      v-if="step != 4"
                      @click="nextBtn"
                    >
                      <i class="fas fa-arrow-alt-right"></i>
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- guide_model end -->

    <!-- bulb_model -->
    <div class="bulb_model">
      <div
        class="modal fade"
        :class="[store.blob_modal ? 'showblobmodal' : '']"
        id="bulb_model"
        data-bs-keyboard="false"
        data-bs-backdrop="static"
      >
        <div class="modal-dialog modal-lg modal-dialog-centered">
          <div class="modal-content">
            <!-- Modal Header -->
            <div
              class="modal-header"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            >
              <div
                class="att_Numberofselected col-1"
                title="Nombre d image sélectionnée sur nombre d image totale"
              >
                <span id="totaltick">0/37</span>
              </div>
              <div class="col-6">
                <div class="divtickcrits">
                  <div
                    class="att_Confirmtheselectionsmade modal_header_menu"
                    id="val"
                    onclick="ftoggleticks(1);"
                    title="Valider les sélections effectuées"
                    style="font-size: 1.3em; display: block"
                  >
                    <b>V</b>
                  </div>
                  <div
                    class="att_Validatetheselection modal_header_menu"
                    id="publish"
                    title="Démarrer la présentation en mode grand écran"
                    onclick="fpublish();"
                    style="font-size: 1.3em"
                  >
                    <b>P</b>
                  </div>
                  <div
                    id="edit"
                    onclick="ftoggleticks(2);"
                    class="att_Viewphotostoselect modal_header_menu"
                    title="Afficher les photos à sélectionner"
                  >
                    ✎
                  </div>
                  <div
                    id="divtick"
                    class="att_Allowsyoutostartthecatalog modal_header_menu"
                    style="font-size: 2em; margin-top: 8px; width: 10%"
                    data-role="none"
                    title="Permet de démarrer en mode zoom le lien du catalogue"
                  >
                    <div class="ui-checkbox">
                      <input
                        class="att_Allowsyoutostartthecatalog"
                        id="barsendallticked"
                        title="Permet de démarrer en mode zoom le lien du catalogue"
                        type="checkbox"
                        style="float: right; margin-right: 10px"
                      />
                    </div>
                  </div>
                  <div
                    class="att_Resetallactiveselections modal_header_menu"
                    title="Réinitialiser toutes les sélections actives"
                    style="font-size: 1.3rem"
                    @click="Showalert"
                  >
                    <span id="close">
                      <i class="far fa-trash-alt"></i>
                    </span>
                  </div>
                </div>
              </div>
              <div class="col-4">
                <div class="divtickcrits" style="float: right">
                  <div
                    id="divtick"
                    class="att_Allowsyoutostartthecatalog modal_header_menu"
                    style="font-size: 1.3em"
                    data-role="none"
                    title="Permet de démarrer en mode zoom le lien du catalogue"
                    @click="HideBlubBoody"
                  >
                    <i class="fas fa-angle-up"></i>
                  </div>
                </div>
              </div>
              <button
                type="button"
                class="btn-close"
                @click="HideBulbModal"
              ></button>
            </div>
            <!-- Modal body -->
            <div class="modal-body" v-if="bulbbody">
              <div class="heading">
                <h4>Catalog Slide Selection</h4>
              </div>

              <form>
                <div class="list_top">
                  <ul class="list-unstyled list-inline">
                    <li class="list-inline-item">
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value=""
                          @click="activeCritria"
                        />
                        <label class="form-check-label" for="flexCheckDefault">
                          All
                        </label>
                      </div>
                    </li>

                    <li class="list-inline-item" @click="HideinnerBody">
                      <i class="fas fa-arrow-alt-up"></i> Criteria
                    </li>
                  </ul>
                </div>

                <div class="bottom_list" v-if="innerBody">
                  <div class="heading_icon">
                    <h4 class="d-inline-block">
                      <i class="fal fa-list-alt"></i> Coiffure
                    </h4>
                    <div
                      class="togltext"
                      style="cursor: pointer"
                      @click="ToggleText"
                    >
                      <p class="m-auto">{{ randomTextone }}</p>
                    </div>
                  </div>

                  <ul class="list-unstyled list-inline">
                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value="Femme"
                          v-model="critriaArray"
                        />
                        <label class="form-check-label" for="flexCheckDefault">
                          Femme
                        </label>
                      </div>
                    </li>

                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value="Homme"
                          v-model="critriaArray"
                        />
                        <label class="form-check-label" for="flexCheckDefault">
                          Homme
                        </label>
                      </div>
                    </li>
                  </ul>
                </div>

                <div class="bottom_list" v-if="innerBody">
                  <div class="heading_icon">
                    <h4 class="d-inline-block">
                      <i class="fal fa-list-alt"></i> Ongle
                    </h4>
                    <div
                      class="togltext"
                      style="cursor: pointer"
                      @click="ToggleTextTwo"
                    >
                      <p class="m-auto">{{ randomTexttwo }}</p>
                    </div>
                  </div>

                  <ul class="list-unstyled list-inline">
                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value="Manicure"
                          v-model="critriaArray"
                        />
                        <label class="form-check-label" for="flexCheckDefault">
                          Manicure
                        </label>
                      </div>
                    </li>

                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value="PDF"
                          v-model="critriaArray"
                        />
                        <label class="form-check-label" for="flexCheckDefault">
                          PDF
                        </label>
                      </div>
                    </li>

                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value="Word"
                          v-model="critriaArray"
                        />
                        <label class="form-check-label" for="flexCheckDefault">
                          Word
                        </label>
                      </div>
                    </li>
                  </ul>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- bulb_model end -->
    <!-- profileinfo_model -->
    <div class="profileinfo_model">
      <div class="modal fade" id="profileinfo_model">
        <div
          class="modal-dialog modal-fullscreen-xl-down modal-dialog-centered"
        >
          <div class="modal-content">
            <!-- Modal Header -->
            <div
              class="modal-header"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            >
              <div class="heading">
                <h4>Carte de visite</h4>
              </div>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
              ></button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
              <div class="social_list d-block bg-light-grey p-3 pb-0">
                <div v-if="!Showdecsinfo">
                  <div class="row">
                    <div class="col-2"></div>
                    <div class="col-3">
                      <div class="profileinfo"></div>
                    </div>
                    <div class="col-6 text-center">
                      <div>
                        <img
                          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAGLxJREFUeF7tXW12FccR7ccCYsgCgpT/ifAGkMRCLMgGkDeAnliAgSzAgBcSSWwAiQUEkQ0YsgBezu2ZO+9OTXVNzdPxv7xzfGxrprurv6puVd+uWZVSNmXB7+LiohwdHZXValUODw/L5eXlpLQ+W6/X5fz8vLAcXkaZ4+PjcnZ2VvAc9V1dXZXNZtN8po145fAc7fLXesfrqicv36syXVyW4ydbeflM2+PfvH4uGN6CHmx++OGH8ujRo7Dc7e1t+fLlyzCwGMS9vb3y7NmzoRyEh5AYDNT3+vXr8u7du/oP/pttXF9fl9PT0/L06dP6DycEE/Xx48fy888/l5OTk1r38+fPy83NTW2DcrIc6kBdXBQ6QCz/9u3bAtnxztevX2tdDx8+rLLzp33BgOJd1Pvt27fRImGd2k/WYcdHF55tzxtotlcnpLXStWC00m0DEHjJjxMyV2ZOztXq3mTDRztT28vs2qifGU0Q9Y9jMJoQCFVVx/dNWd3rtj9mFyvSNgg19Pnz5/L+/fuqulAhdgJ2Ed7lKrL/xu7Bavrt/fvyuC+nE9K1dwIFNJIf7WFVQxa2ZzuIdvljX7Cq9/f3667loKM8VKaudMgE+SEL/8FYoE72k3WjTsiCZyiHMcDE4/1oAXB8UA/bZl/cCeGga0e5KnVCDo+Oyj3o6zqdZWwLPlyFVol24snxcXlhbAjajewS5aJ9iFac7Yvap8yOjnZtZCcytlLbt7ZutEPW67Nyfv5yJK83ITTqnBCsFvzDlYPV189V/RtWteprrlTshv39v5aTk58GnX7//v2RPYOdgN5X8DCdEKjI8Y7ihLx69arWB5lhQ6CrsVKxqvnDZOHvsF1cudqXg4ODwR5yN6A+/GydF/+6KEfH3bOWGmS7kNguSjMhHSKa2yHDhJilpghsspplzCgo39FVZVevt1KX7BCv7szu8dBkLffyvNRB7yeE3crYkKgvd1JZdkKa8PXJ8aC+MnBQwYA3aJwsT7XaibQytdUhkCHAwPiXmUit8w+ZEEJUFY3w1TbIFYJ38d9QU4SoCl9ZF1THjz/+WP+X0JZqje+gHKEtZbm+/li+fftvVSWErYCyUB1QJVBx+uM7dkKgegnTCUMJNbUvdtfCUFMmbyFAhjdv3lRjDvkV3luVRZiu8lroP1JZU028LeqtgHjFwuhvFrqdU6PuOY2RqsvAV2/36CBhUP7lOMCejZ2oZqnIyjLZhvKHkcoinLQQFe/zbxbWwdZYSExDqM8UfqIdfXZxeVk+XF0NYADPCCIGCN77NHD6qNL4jGqFdk+h7ZIoAKG4Qnj0XdvU/yZ81XJnL87K+nw9QP8pzH5SNpvvQzTBjjV2PVyGQWtY9dGazaaxk/AIfJjDx11Yxe6sGqbAs6vGsz4c45YLnnHx7LJDbMjmbL0ux4lwThTqiWB2tFNWFxcXi9xq2BTobXScThEcJ8yuPoPehc2g46PPCG056NDDDx48qP4M67TOJp7ZclwchMTY9mNIvV/tFUMghKh212o57izYF7zvPfPUaAfh94fdrjDbnwDfQKw2S+Mcjo6MZjyCqBH8jIKDkT3DYMPptKvMQ3B/RFglgvDROPFZqKmiTmwjpBdlvT5v+i9sKBvRtepMO0H7ApXyEv5SQs96vpEdmEi9oAmEeJrqNxHxtmOg7U889cPDw6bKgrG0MJSwDgNsITEbwsDx2WRCvm+q/fDC7wpNPQheIeY/31THTD13QFP8UJ6w1yIxLKBWVJtxObTJqK32hXCZ0BZQFeoJY4DJuurVN9Q2jTWecQGxTroFnZy/l5ubT+Xs7EVd0ITETZWFWUK8ai7CClxrd0i3s8Y6MrNDsobQqkGG3b3yS85vgPrO+/MbTsjcGY0NLXk7OqOaB5UFG0JDaqEYKoKxwrlEK2qrkU7thDXO0YRwZaI9G1YhlEbdWid22MlPJ2Vvf2+AkhqZ1YgwJgzP7OJ6++5d+U+/qglzCe/ZrsJdRoEpL8rQZYDcumv1mZ0QlZN1cnzrDrGDkDE+c9HTJfBT24viXK1n3sldJnSScTqjk9HMOOGdTKhn2CFHR0cbOni2AaxC/qKoLd9hZBU6+fffoSO70znoW8JPhYMcNEZ0sToJTVknnTDvmUJpaEgcs/JnJwTlucPYF0JblZfPWDdtDyA8VzH7ifGxkWB9xvfpFuj4spwd8/DE0DujHq/mi3J8/GT4UwbRRAjDQ+C6iudW5NyZ+iSU0Zu5qJ/RuXnEHfDKefZl5wmJBqNlZL0yOSg99eK1rsgPieR0VfOq1BPSVtxpjrBh29MQewSIWmZiBdjbioJioC0xgBFSCGJJBxROo6eEfIzMquEjtFUYyU545AhVY5Y4wWctIgOgMVSHB201Ok0iA+VVeB/JxH52pIrP5erqQ1VniATb6DJkpSyUeyA5qFFfEpBDRfOQeGvQsodQmTozu2C6a++Vw8PHIwcvqmepx+3F3lr2zBu7IdrrTQhXEbarEhlIDECFGpm1BlhjUqqiqFctiKAwKIcfoab+m8/m7AjJCqxH4atGkrErlHRgZcKuVaoQ6tMINOlO6jLgHZZTAgQXB8eVEW+4ExqzQ10j2JuxBZGjlXH+otVRoXRPSrMDnwm5qSsaRYtVtaqXb/0IK8MSB48TqBEJ1heCCG+HEIbCrb++vhmIa5h9L9obwUgbBYWAjASzXOQPEEYidvW9J+KxnMJl1cUgK9hoMQZb7RMcWiUy2GcKX1k3VvDtl9vh0E19MfZTz4+8E8M5woa7Q6KVrqsmQiZ2dU0g8aqUeqjToJKyfESc8CBxyyHVnbnLWUunS8c8vF2dYx2biVaKPHUXovY0lwjz28loHYlu39sqm8jDt/UqxMSzyI+JQMi8v9XmIs/JhOcZUzCos8vLy00EB220lxBVjSxJDuTRUi+jEUI+hbaEgxRCyQrk/do6R/q9nz8lDeBPUGuUl1PMdyBTC4Z6faHqgSqLZLIwm+3haPpPPWeafWE/I6fRJcrpzrQw1FMTSyFfS53p33dx/lpxJ0auWX/m8Ivv7nqwpbLw/CYTyVidnZ3V8xBUwEinCs5nXDE8jFdBGekk5ENdhJFehJT1E0YqWYHlNHpqVxS5x0qqoMpi9HWiNvurCsoW1CizyqSQmBFv9M3K5JEqlN/88C8Py7N/PBvGlTxjjB3hMtsd4PmcDWm5+BEMzUZIl0LTOaAwJ5PdIbY+/f8oBJKF9636m+c2h0dlhWgvI7M2outFQdmIhkf4N+XhEtpuI6S/lEePOqIcfxHJocpy8rRc33RkA408s7xVAZCpGUVdrYZn1sFTmSyER7uqtqFOlJHSIk54kXKOD8bEcoJJ9BgBuQgN1Gdna8tp7vrSW1CLerSjGWqmdzrHOuairnwvYs9Hp3ut3ePt9rvaUe5kDBtPKDkRoyPcDDsxxctyrpZtB3Z7qWa7AKaw1+4C/P/cAVU0obW8iQJkfZyWv+XJ5KmpJcybFWDvYLB/fVve//a+KA/Xep5b2Pui7O3t1+Ndy2vlIRS8Um/XtaLE2kELl7m6VRVwQKk+oWLtlTgPUnPQSNjgIdTBo0dVHaENQnivTg8SW3IE2rD9ZEQXffn969fy6eZmGLthwWYJuJlIsGiv1PnCaDX1myRz9OvtHvwtUmstA8ty4T2YRmEPEuurkcvQjHIA9o4h2Gq4QKM8XApOITQSTF4rhUE5vkfYq7bACmqveuFdlqO+hjr1UBSjrnZCLMkBz21El+2iXktW8CA8+6DlbLRXeb862eiHwmwbleauc0kOd7cTuSvT7GAGYuLdOSd1LpwzV97bCHNGfbvSO35VNg7ItmwE2YW93gE/V5w+I8TklTY2AiEtoWAbQd7yd220F1cAHvRX2njtjOQInRA+ozOFQYDGA2FNZUC4JIroqmNpyQqsR892rLxoVx1ZtOdxie34KDmiRpBvbwe5l8He/pZrhkQ3sQWHR+XqQ5wcIKuTM2GVpRHdFiTGFYLLi6tR4gBvR3tnJS27FTnOi1UWG5kjK+gK0xD7VsjtWlh6XBoZ6FZkQctkOFtRG9GzDMkBjFDydyfcXmBeRjPZkMJBSzrQDAeMdFrOqxc9VV4rvQ5CRb0GRuMGVfBwb290t7ZFuICM/Nm+8O8agVY+GN6PIsFat7aBKw7DMzmq1Ai0zXShxAl605MrbdF1hFmDZnKARB5stLO8Fec5U0vOSmydWe5VFAm2IGTuWLnliHr9HZEcrCHkKvW4vYz2Kgy1EV2N9nq8VnU27cpVYVGP5fbCoBNOqiw64VxIkEv5uwQaHHS90qyDbSGqHUBdeK0LRijjZYAAixM/D4IPJAc2uISDijJ3jRvZjs6dPSyRM+vIpm2FqKW7RnvDsUO0l5CPEOz0FBl4PlVZW9FTQDdeMRtIB89Py82nLlzCZxbWzRlEPmc5wmwtx4VDIoI+Y0YGj1PMVUkYSiiO8ty1/DcIFTV9iDMGHifY4xLbvmp702h4l3HC5fZmkELkhM3p1vSqbLzowV4u4AhltRzDOXkiTcCyedvzwU1RNjjjmp5pV+wedSgTQVb939LXus1bR8ZetHfXI4FdI8FZddZaHG6uk2zoJEP7/P+ETDPneTZkQFlRArPQo5QzD2+HRNHTaCIzR8bRJEe8LCtnZuFFu3+p2s7EuSr7nRc06ajRsPFIFAxua/SQgoiZM7wUdlGOlFZ7SrnxWPO8KMlcJ3puw4HjeYjnjUcTYnOW8NwHZXiuYccHbdB2eekKVRVj8ugcq2q1bHv3xHB63Ti+f5w5Ecse4Vpoi4AjDo3wy4RF8J6Xh8pb6Rk74dmurM1r7a4myQHJRdfrdXXWAfEA9ewvcnwswuD/a86tjlr0oZ6xMNWeHXRNmWefKUWI6I0kBXUaa7lNqdxb8HY9xjnrtmclSvWxTq6y/KkqvRR/w6lrn7NEo8TaHmQgMx5OrvYF4xNGe3VVRipgCVVyqfO3RM8zBJ9lnGfhfcseRrt2ivhw1WKc9Y6Towt4NCF0ptThopqwjhYGik6YBuvI7tbzBSS8/EVS7bEcV46eGLKcNdyQwzqbntNIeo13RsMdwmd08PD3VmpBdXI9MGEvqbIN8gqYxhYhIh1XjoG9EOoaB9X3EerZhWk+t+uYGSFz5hEhoLs+y1B9sm14fWmN67JbuGfrmuCRWahbAilczgxspvOZOiMSsxc9yBwdR9QiTyY1+HO0Jbw7OQ/x/BCeeeBlnkEQnmkaPwuFvYuSdkI4megMy2udUW6VVs4RVRM2n4l3fkOYzgmB6rRnF5oR22oCTQ1IuEwoTllQhhDcUpq886Ih14k3IZ4Dk9meEbTNML8VYnrtZZy+JdSbqJ+e2s74Np7cUZxrQnLAhDCfCY2sjffzDKIFifn37IS06DgQXOk4upvwzE6IXqJUSEuWOu5o/NrD0InqMeqXtByPkW8pTUO7L88nOSUtIx9yEUqzHkyC7iRl27uw19Pp0YpdOiEZOo5HGmiSyySM0yYrtL+8YKE4Lv54STDtGGT5xtH4qLrFAkxPCKk3ehmSrHltEGnIkdGNP55rcPcofPXoPLYczxCUchNBWpsGMJt/pQW31XDj9BEQnnWiL/ZniXL63IP3O09IK+StDUZ2IqPOvF04IKFV6ZJnXlx27FfHydLyGXn1/Uww1N6EiuTdFdUlkuR1zUbxqozB13eWRHRZLnvo5am1uenLMx7HNc3BXjsuLO1H0bundUJsNFMr4jOsVKgi3hXHOy2IqdQZGyFFOQsHCSMxmF2dB40sdZ1kXp2UmRdYIS8ZglBjmqHaDhS9akQZCO/1AiuhLWH635FF9f790VeGbEpCTY/4+fa2JkpTt6CVX8Y9oFKBrefsbXOrB+cYiHw/IqxFTMCIjJFRPV3749WeceIotxdfs5M858i2IPxoQggXh8o3pabQ0wuParTsBUvNkdJlcb7XvEjKNiA46Tz4GyE4L6BqrpJxJm18VqOLTqujRZmi42i2rX1RNrrKtoWoIJA/rhDWMuM1BaKVl/dnyDMmDYgUIRuVDkMnS42WdqRlV7K7J1qN093zvZRN/4GZvmBmQiJ4753FZ6LaWQfYaolh7JDZmlDRg7Z8kfrTY4zzHb302WKT8xQS9FGPIsQoKKlFXMXYvVYdKaSlDEppgu5+33+GSctTYenlTbuANBLMZ3QaORaYIMprFxDetX3xFqmlJIV3DOccHyY9ZkPwQeAd49dy0PSZJ+AuEWSVM6L6ZBxSd2f35iZyVunRtUMu/nkI23NJDnab4xSRWZ2jwVuiXkaTddZ9sUZ3If877HxLH84kVWtNdtZniMBExJTMjM+Il9X6KMmAFC4u69EoMjfrJcoImdgoqJZrZcTewt5HQ2pVltPs0+P52KIlj8Wu737Ed6ZOT4cP0GhE186xx2Iny99bD4TZelnU5pDJnH7OXthZcny5q6c+GDQnzzpJDhElaSgfXMfWQcyc0ej7U2dz6mruSjKclFNeo4ciOCGExJr67vJynCZ2nMsD3zj8beiXFzqxMNsjFLAcBPdgNnYtYa+1JTX7df/NwaUTonEnQmK0g/AJgQLq9D5qA2hLNQiZCOG9vugY4N3GDund+Jnc75njXas/A/U/8nx15QAsTOkBXVhbTy8nHSpl+NCjrunMDolgr3fSmLF50U2xkVHnINk0dUplsaeDqNwe8GdyeaCcp69Jjmh9CEa/zGnzkaAz+Gn0lRCeg6AJB+wFVq2b/eTlTSVz2HSFaLPF8odMXLCUd0LKcK44hMFFj9DlISIL3SLnbw7RsK7ICcsEOqNob8bB0362wEu027lAPEpSCxRMzkM89ZLxCyLB+GWzP5rJYmXwIGrmgpG3uOwY0N+aizosucagwGYS7fUGz4uCskEv+qpMPjAJycNlGawcywlWaGthJAS2JAe9LDpMSK8GbPRVITFl05R7dvCe45Ov/afBM/4L2+N3F5U4YTNbeyQHyhReR9BtZ3dPdBYQ7ZiltJqIbDCnMvT5bNTBfrpI9HtmQjI7K6I7jXaIF2FlVNLT+aTw2MiqN0CWnQhV4kU6+bkg7wMpaI8AAytR+bcKe5ljBe8/Pnxcjo+Oh+zVXj80aqvwXjNAoE+EvWzXkkD0+4d8hn5qmxwz1If/rnD55Gn99iHkHqLE7v0qGdlM/GdJSGFbNQYZ+UHWE/iqE5uJyCrmt6AgQ9iYO7uwC82jD2XOdlKe+tx3DG0k2Iv2ckImHzp59bqep2DVK3ZnRJbR0yiCrN8T5MAQ0tpnCnstRCU0Rh0sT73tRZJVVW6jtj+Vp0+f1Sgu7qrgU+f2Iqn2kxCe/F2m8Yv4wunvGO4aGrC6Ff/PXeelT41uV7Eud0c2AHxErujq6wpmQkRRJMPrZ8vGeehs2D27fljSIwYMhkk8/IwHGxnnpWyVKOCZgaEtO+hRfrx3MypWy00mWVP8WW8cBSP+Lnm/vM6lMNJGkCmEpszLoCROiLIYyaPVZ7rzvDSAXnBSObotwgbqtRmxKbdHnOgm5EP9ELHNzcLJwsKwnxkfoazMwPCdyMGrz5B79t428hR5xRkOUiaCzN3qRRbwEcp6H9KJy3kxqUj1LFFZHrxvg4Ht4VUdE8u19SaIBtibEEJbhZEW7WhaPFt/xParWl4+3Y3/t7KQiIB/U2VRJpbXaLFCcUBa77PhJF5snbhtwFWvtNkItIXECtP5DKlh//25i4aDOKFR6THJIWCUeRHS6TlBbyadc4mRbjXtRHo3ClO0QvreZ11DvT1j80gZWhIlnvo9m3J0dFyj095vdGJIY2fhIPUnQhQUxrsVa7eyGkALbRV+WvUA1VLzuvdZgLDjdLL0GhiIZ387OCh/fvBg1L/W9xM1auupHhtlVptHO2rhq46PTUkIuVmOeVM0XaHNIUMtMUuU2wUO6ghlVxXIEXoHOHNGvcT2zYVsrIodjGw2QYLhB8zJ1nK4d56QpbGhTBwnMoTRNvcGL5rQzAUaz6u2MnhjwHfaxwxd8pkmw9JLPqMNR9RMCxX1096Wu8oJUSLDNkJ6XZAyD51gij5C6YFssCnl67evw+dcUX/X3sHAhFd1aDMr6GRH1/MspEadNvOEcnRbaQe1nxzPiDgxpFW8y4REXvWSc5RMvInoKnvgY+1TdNhmM1dAbfDCzpz6XdJPrasJiHRCLOkAFWS4sjTcyuizmZuVv2snsuMEf65c4A6Cn0zufwCask6U12NXPV+wmSc0+uql3EP/9OK+hfAYA9ZJsgLJHHhG1aQRaEJpRtE5Lhqz88ohcp3m9mZiWZ7+vOvJXca4qr6OVqy1AZ7T6R0Pt8gcqG+iJXpIv6uNHe6H6OepOaNcAaickE87YaOZjPZitbQyFaB8Juu1ykB11Uo3qLbDZnLgDvHIFV6WbrvbUc6SFTix3jcZvQVkSQ4YT5sekZHrTPRitLAyoQzV93ZVZkMKHqrKRIJtuYx9mrsJtcQBjhBf5tn/AO0vhdhN6NbzAAAAAElFTkSuQmCC"
                          alt="qrcode"
                        />
                      </div>
                    </div>
                  </div>
                  <ul class="list-unstyled list-inline p-2 text-center">
                    <li class="list-inline-item">
                      <a href="javascript:;"
                        ><i class="fab fa-facebook-f"></i
                      ></a>
                    </li>
                    <li class="list-inline-item">
                      <a href="javascript:;"><i class="fab fa-twitter"></i></a>
                    </li>
                    <li class="list-inline-item">
                      <a href="javascript:;"
                        ><i class="fab fa-instagram"></i
                      ></a>
                    </li>
                    <li class="list-inline-item">
                      <a href="javascript:;"
                        ><i class="fab fa-linkedin-in"></i
                      ></a>
                    </li>
                    <li class="list-inline-item">
                      <a href="javascript:;"
                        ><i class="fas fa-map-marker-alt"></i
                      ></a>
                    </li>
                    <li class="list-inline-item">
                      <a href="javascript:;"><i class="far fa-globe"></i></a>
                    </li>
                  </ul>
                </div>
                <div class="pb-3" v-if="Showdecsinfo">
                  <img
                    class="w-100"
                    src="https://www.mobislide.fr/data7/coiffeur/photos/cards/Benoit_verso.png"
                    alt="qrcode"
                  />
                </div>
                <div
                  id="versovcard"
                  versocard="1"
                  @click="fturnVisitcard"
                  class="versovcardchange"
                >
                  ↺
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- profileinfo_model end -->
    <!-- exit_model -->
    <div class="exit_model">
      <div class="modal fade" id="exit_model">
        <div class="modal-dialog modal-lg modal-dialog-centered">
          <div class="modal-content">
            <!-- Modal Header -->
            <div
              class="modal-header"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            >
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
              ></button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
              <div class="heading">
                <h4>Recapitulatif visite</h4>
              </div>

              <form>
                <div class="form-group">
                  <label>Commentaires sur la visite</label>
                  <textarea
                    class="form-control"
                    placeholder="Commentaires sur la visite"
                  ></textarea>
                </div>
                <div class="form-group">
                  <label>Actions a mener</label>
                  <textarea
                    class="form-control"
                    placeholder="Actions a mener"
                  ></textarea>
                </div>
                <button type="button" class="btn btn-trashs">Valider</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- exit_model end -->
  </div>
</template>

<script>
import { store } from "@/stores";

export default {
  name: "ModalsComponent",
  data() {
    return {
      store,
      step: 1,
      widgetLength: 4,
      progressWidth: "25%",
      bulbbody: true,
      innerBody: true,
      staticText: ["OU", "TOUS", "ET"],
      randomTextone: "OU",
      randomTexttwo: "OU",
      critriaArray: [],
      Showdecsinfo: false,
    };
  },
  methods: {
    setProgress() {
      var percent = parseFloat(100 / this.widgetLength) * this.step;
      percent = percent.toFixed();
      this.progressWidth = percent + "%";
    },
    nextBtn() {
      if (this.step < 4) {
        this.step = this.step + 1;
      }
      this.setProgress();
    },
    backBtn() {
      if (this.step >= 1) {
        this.step = this.step - 1;
      }
      this.setProgress();
    },
    HideBulbModal() {
      this.store.blob_modal = false;
    },
    HideBlubBoody() {
      this.bulbbody = !this.bulbbody;
    },
    HideinnerBody() {
      this.innerBody = !this.innerBody;
    },
    Showalert() {
      alert("Réinitialiser tous les cochages ?");
    },
    ToggleText() {
      this.randomTextone =
        this.staticText[Math.floor(Math.random() * this.staticText.length)];
    },
    ToggleTextTwo() {
      this.randomTexttwo =
        this.staticText[Math.floor(Math.random() * this.staticText.length)];
    },
    activeCritria() {
      if (this.critriaArray.length > 0) this.critriaArray = [];
      else this.critriaArray = ["Femme", "Homme", "Manicure", "PDF", "Word"];
    },
    fturnVisitcard() {
      this.Showdecsinfo = !this.Showdecsinfo;
    },
  },
};
</script>

<style>
</style>