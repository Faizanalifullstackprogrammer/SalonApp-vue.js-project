<template>
  <!-- guide_model -->
  <div class="bulb_model">
    <div class="modal fade" id="youtub-model-show">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <!-- Modal Header -->
          <div
            class="modal-header"
            :style="{
              background: store.appdata.catalog.config.catalogbgcolor,
            }"
          >
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
            ></button>
          </div>
          <!-- Modal body -->
          <div class="modal-body">
            <iframe
              width="100%"
              style="
                height: 760px;
                padding: 10px;
                background-color: rgb(221, 221, 221);
                border-radius: 8px;
                overflow: auto;
                resize: both;
                box-sizing: border-box;
              "
              :src="store.activeYoutub"
              allowfullscreen
              allowtransparency
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- guide_model end -->
</template>

<script>
import { defineComponent, ref } from "vue";
import { store } from "@/stores";

export default defineComponent({
  data() {
    return {
      store,
    };
  },
});
</script>