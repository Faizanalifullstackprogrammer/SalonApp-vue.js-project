<template>
  <!-- footer -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-6">
          <div class="foo_widget">
            <div class="logo">
              <a href="/"><img :src="logo" alt="" class="logos" /> </a>
            </div>
            <div class="logo_desc">
              <p>
                Office: {{ store.appdata.catalog.company.datas.adress }}
                {{ store.appdata.catalog.company.datas.state }}
                {{ store.appdata.catalog.company.datas.zipcode }}
                {{ store.appdata.catalog.company.datas.city }}
                {{ store.appdata.catalog.company.datas.country }}, Phone:
                {{ store.appdata.catalog.company.datas.telephone }} Email:
                {{ store.appdata.catalog.company.datas.email }}
              </p>
            </div>
            <div class="social">
              <ul class="list-unstyled list-inline">
                <li class="list-inline-item">
                  <a href="#"><i class="fab fa-facebook-f"></i></a>
                </li>
                <li class="list-inline-item">
                  <a href="#"><i class="fab fa-twitter"></i></a>
                </li>
                <li class="list-inline-item">
                  <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-2 col-sm-6">
          <div class="foo_widget">
            <h3>Quick Links</h3>
            <div class="foo_nav">
              <ul class="list-unstyled list-inline'">
                <li>
                  <a href="javascript:;">{{ $t("ABOUT") }}</a>
                </li>
                <li>
                  <a href="javascript:;">{{ $t("CONTACT_Us") }}</a>
                </li>
                <li>
                  <a href="javascript:;">{{ $t("MY_ACCOUNT") }}</a>
                </li>
                <li>
                  <a href="javascript:;">{{ $t("SHIPPING_RETURNS") }}</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-2 col-sm-6">
          <div class="foo_widget">
            <h3>Services Design</h3>
            <div class="foo_nav">
              <ul class="list-unstyled list-inline'">
                <li><a href="javascript:;">Service 01</a></li>
                <li><a href="javascript:;">Service 02</a></li>
                <li><a href="javascript:;">Service 03</a></li>
                <li><a href="javascript:;">Service 04</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-1 col-sm-6"></div>
        <div class="col-md-3 col-sm-6">
          <div class="foo_widget">
            <h3>CONNECT</h3>
            <div class="media_flex">
              <div class="icon">
                <i class="far fa-envelope"></i>
              </div>
              <div class="media_desc">
                <h4>
                  Do you have any Support?
                  <a
                    :href="
                      'mailto:' + store.appdata.catalog.company.datas.email
                    "
                    >{{ store.appdata.catalog.company.datas.email }}</a
                  >
                </h4>
              </div>
            </div>
            <div class="media_flex">
              <div class="icon">
                <i class="fal fa-phone-alt"></i>
              </div>
              <div class="media_desc">
                <h4>
                  <a
                    :href="
                      'tel:' + store.appdata.catalog.company.datas.telephone
                    "
                    >{{ store.appdata.catalog.company.datas.telephone }}</a
                  >
                  <br />
                  Sun - Mon: 10:00 - 12:00
                </h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="copyright">
      <div class="container">
        <p>© 2020. All rights reserved.</p>
      </div>
    </div>
  </footer>
  <!-- footer end -->
</template>

<script>
import { store } from "@/stores";

export default {
  name: "FooterComponent",
  data() {
    return {
      store,
      logo:
        store.apiUrl +
        "/data7/coiffeur/photos/logos/" +
        store.appdata.catalog.logogen,
    };
  },
};
</script>

<style>
</style>