<template>
  <div>
    <img src="@/assets/loader.gif" :style="{ width: '100%' }" />
  </div>
</template>

<script>
export default {
  name: "LoadingComponent",
};
</script>

<style>
</style>