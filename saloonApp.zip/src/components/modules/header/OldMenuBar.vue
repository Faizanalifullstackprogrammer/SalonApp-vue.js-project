<template>
  <div
    class="list_bars_sidebar content_box_cover"
    :class="[toggleSidebar ? 'active_sidebar' : '']"
  >
    <div class="top_detail">
      <div class="edit" @click="manuToggle('loginform')">
        <a href="javascript:;"><i class="fad fa-edit"></i></a>
      </div>
      <div class="close close_sidebar" @click="parentCall">
        <i class="fal fa-times"></i>
      </div>
      <!-- form -->
      <form :class="[activeManu == 'loginform' ? 'active_submenu' : '']">
        <div class="close" @click="manuToggle('loginform')">
          <i class="fal fa-times"></i>
        </div>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Nom" />
        </div>
        <div class="form-group">
          <input
            type="password"
            class="form-control"
            placeholder="Mate de pass"
          />
        </div>
        <ul class="list-unstyled list-inline">
          <li class="list-inline-item">
            <button type="button" class="btn btn_sub">
              {{ t("LOGIN") }}
            </button>
          </li>
          <li class="list-inline-item">
            <button type="button" class="btn btn_sub">
              {{ t("LOGOUT") }}
            </button>
          </li>
        </ul>
      </form>
      <!-- form end -->
      <div class="social_list d-block">
        <img
          :src="logoSignature"
          alt=""
          class="img-fluid"
          style="width: 200px"
        />
        <ul class="list-unstyled list-inline p-2">
          <li class="list-inline-item">
            <a href="javascript:;"><i class="fab fa-facebook-f"></i></a>
          </li>
          <li class="list-inline-item">
            <a href="javascript:;"><i class="fab fa-twitter"></i></a>
          </li>
          <li class="list-inline-item">
            <a href="javascript:;"><i class="fab fa-instagram"></i></a>
          </li>
          <li class="list-inline-item">
            <a href="javascript:;"><i class="fab fa-linkedin-in"></i></a>
          </li>
          <li class="list-inline-item">
            <a href="javascript:;"><i class="fas fa-map-marker-alt"></i></a>
          </li>
          <li class="list-inline-item">
            <a href="javascript:;"><i class="far fa-globe"></i></a>
          </li>
        </ul>
      </div>
      <!-- contact -->
      <div class="contact">
        <div class="icon">
          <ul class="list-unstyled list-inline">
            <li class="list-inline-item">
              <a :href="'mailto:' + store.appdata.catalog.company.datas.email"
                ><i class="fal fa-envelope"></i
              ></a>
            </li>
            <li class="list-inline-item">
              <a :href="'tel:' + store.appdata.catalog.company.datas.telephone"
                ><i class="fal fa-phone-alt"></i
              ></a>
            </li>
          </ul>
        </div>
        <div class="contact_heading">
          <p>
            {{ store.appdata.catalog.company.datas.adress }}
            {{ store.appdata.catalog.company.datas.state }}
            {{ store.appdata.catalog.company.datas.zipcode }}<br />
            {{ store.appdata.catalog.company.datas.city }}
            {{ store.appdata.catalog.company.datas.country }}
          </p>
        </div>
      </div>
      <!-- contact end -->
      <!-- section_list -->

      <div class="section_list">
        <ul class="list-unstyled list-inline">
          <li>
            <a
              href="javascript:;"
              data-bs-toggle="modal"
              data-bs-target="#share_model"
              ><i class="fal fa-sign-out"></i>
              <span>{{ t("TO_SHARE") }}</span></a
            >
          </li>
          <li>
            <a
              href="javascript:;"
              data-bs-toggle="modal"
              data-bs-target="#guide"
              ><i class="fal fa-info-circle"></i>
              <span>{{ t("GUIDE") }}</span></a
            >
          </li>
          <li class="about_box" @click="manuToggle('aboutus')">
            <a href="javascript:;">
              <i class="fas fa-plus-square"></i> <span>{{ t("ABOUT") }}</span>
            </a>

            <div
              class="about_detail"
              :class="[activeManu == 'aboutus' ? 'active_submenu' : '']"
            >
              <ul class="list-unstyled list-inline">
                <li>
                  <strong>{{ t("CATALOG") }} : </strong> 12/05/2021 09:34
                </li>
                <li>
                  <strong>{{ t("DISPLAYED_LINES") }} : </strong> 3/3
                </li>
                <li>
                  <strong>{{ t("DISPLAYED_PICTURES") }} : </strong> 26/26
                </li>
                <li>
                  <strong>{{ t("PICTURES_SIZE") }} : </strong> 7816k
                </li>
                <li>
                  <strong>{{ t("DOWNLOADS") }} : </strong> 231
                </li>
                <li>
                  <strong>{{ t("CREATED_BY") }} : </strong>Mobislide V1.30
                </li>
                <li><a href="javascript:;">www.mobislide.fr</a></li>
              </ul>
            </div>
          </li>
          <li>
            <a href="javascript:;"
              ><i class="fal fa-qrcode"></i> <span>{{ t("QR_CODE") }}</span></a
            >
          </li>
          <li>
            <a href="javascript:;"
              ><i class="fas fa-user"></i><span>{{ t("CONTACT_Us") }}</span></a
            >
          </li>
          <li class="language_box" @click="manuToggle('language')">
            <a href="javascript:;"
              ><i class="fal fa-language"></i
              ><span>{{ t("LANGUAGE") }}</span></a
            >

            <div
              class="language_detail"
              :class="[activeManu == 'language' ? 'active_submenu' : '']"
            >
              <ul class="list-unstyled list-inline">
                <li class="list-inline-item" @click="setLocale('fr')">
                  <a href="javascript:;">Fr</a>
                </li>
                <li class="list-inline-item" @click="setLocale('en')">
                  <a href="javascript:;">En</a>
                </li>
                <li class="list-inline-item" @click="setLocale('he')">
                  <a href="javascript:;">He</a>
                </li>
                <li class="list-inline-item" @click="setLocale('ru')">
                  <a href="javascript:;">Ru</a>
                </li>
                <li class="list-inline-item" @click="setLocale('es')">
                  <a href="javascript:;">Es</a>
                </li>
                <li class="list-inline-item" @click="setLocale('nl')">
                  <a href="javascript:;">Nl</a>
                </li>
                <li class="list-inline-item" @click="setLocale('ar')">
                  <a href="javascript:;">Ar</a>
                </li>
                <li class="list-inline-item" @click="setLocale('cn')">
                  <a href="javascript:;">Cn</a>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
      <!-- section_list end -->
    </div>
    <div class="bottom_detail">
      <!-- barcode_sec -->
      <div class="barcode_sec">
        <div class="secsor_code">
          <div class="thumb">
            <img
              :src="logoQR"
              class="img-fluid"
              :style="{ width: '200px' }"
              alt=""
            />
          </div>
          <ul class="list-unstyled list-inline">
            <li class="list-inline-item">
              <a href="javascript:;">{{ t("REFRESH_SCREEN") }}</a>
            </li>
            <li class="list-inline-item">
              <a href="javascript:;">{{ t("SAVE_CHANGES") }}</a>
            </li>
          </ul>
        </div>
      </div>
      <!-- barcode_sec end -->
    </div>
  </div>
</template>

<script>
import { store } from "@/stores";
import { useI18n } from "vue-i18n";
import { ref } from "vue";

export default {
  name: "MenuBar",
  setup() {
    const { t, locale } = useI18n();
    return {
      t,
      locale,
    };
  },
  components: {},
  props: ["toggleSidebar"],
  data() {
    return {
      locale: ref,
      activeManu: "",
      store,
      logoQR:
        store.apiUrl +
        "data7/coiffeur/photos/logos/" +
        store.appdata.catalog.logoQR,
      logoSignature:
        store.apiUrl + "/data7/coiffeur/photos/logos/signatureNoir.png",
    };
  },
  methods: {
    parentCall() {
      this.$emit("passData", { methodCall: "ToggleSidebar" });
    },
    manuToggle(item) {
      if (this.activeManu == item) {
        this.activeManu = "";
      } else {
        this.activeManu = item;
      }
    },
    scrollHandle() {
      // console.log(evt);
    },
    setLocale(locale) {
      // this.loading = false;
      this.locale = locale;
      this.$router.push({
        params: { lang: locale },
      });
    },
  },
};
</script>

<style>
</style> 