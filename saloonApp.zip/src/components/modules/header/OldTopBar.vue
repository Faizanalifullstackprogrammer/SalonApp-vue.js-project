<template>
  <div>
    <!-- search_top -->
    <div class="search_top" :class="[toggleSearch ? 'active_search' : '']">
      <div class="close_search" @click="ToggleSearchs">
        <i class="fal fa-times"></i>
      </div>
      <h3>{{ t("SEARCH") }}</h3>
      <form>
        <div class="form-group">
          <div class="search"><i class="far fa-search"></i></div>
          <input type="text" class="form-control" placeholder="" />
          <button type="button" class="btn btn_ok">OK</button>
        </div>
      </form>
    </div>
    <!-- search_top end -->
    <!-- list_bars_sidebar -->
    <MenuBar :toggleSidebar="toggleSidebar" v-on:passData="fromChild" />
    <!-- list_bars_sidebar end -->
    <div class="top_list_nav" :style="{ 'background-image': bgheader }">
      <div class="container-fluid">
        <div class="list_bars icon_renew" @click="ToggleSidebar">
          <a href="javascript:;"
            ><i
              class="fas fa-list"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            ></i
          ></a>
        </div>
        <div class="logo">
          <a href="/"><img :src="logo" alt="" class="logos" /></a>
          <div
            class="banner_close"
            :style="{
              background: store.appdata.catalog.config.catalogbgcolor,
            }"
          >
            <a
              href="javascript:;"
              @click="store.toggleHeader = !store.toggleHeader"
              ><i class="fas fa-arrow-alt-up" v-if="store.toggleHeader"></i>
              <i class="fas fa-arrow-alt-down" v-else></i
            ></a>
          </div>
        </div>
        <div class="search_bar icon_renew">
          <a
            href="javascript:;"
            data-bs-toggle="modal"
            data-bs-target="#bulb_model"
            ><i
              class="fas fa-lightbulb-on"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            ></i>
          </a>
          <a href="javascript:;" class="search_slide" @click="ToggleSearchs">
            <i
              class="far fa-search"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            ></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MenuBar from "@/components/modules/header/MenuBar.vue";
import { store } from "@/stores";
import { useI18n } from "vue-i18n";

export default {
  name: "TopBar",
  setup() {
    const { t } = useI18n();
    return {
      t,
    };
  },
  components: {
    MenuBar,
  },
  data() {
    return {
      toggleSearch: false,
      toggleSidebar: false,
      store,
      bgheader: store.appdata.catalog.bgheader
        ? "url(" +
          store.apiUrl +
          "data7/coiffeur/photos/logos/" +
          store.appdata.catalog.bgheader +
          ")"
        : "url(https://vuejs.org/images/logo.png)",
      logo:
        store.apiUrl +
        "data7/coiffeur/photos/logos/" +
        store.appdata.catalog.logogen,
    };
  },
  mounted() {
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        this.toggleSidebar = false;
        this.toggleSearch = false;
      }
    });
  },
  methods: {
    fromChild(data) {
      if (data.methodCall) return this[data.methodCall]();
    },
    ToggleSearchs() {
      this.toggleSearch = !this.toggleSearch;
    },
    ToggleSidebar() {
      this.toggleSidebar = !this.toggleSidebar;
    },
  },
};
</script>

<style>
</style>