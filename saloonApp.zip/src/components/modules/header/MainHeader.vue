<template>
  <!-- header -->
  <header>
    <TopBar />
    <div class="middle_banner" :class="store.toggleHeader ? 'h-0' : ''">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-5">
            <div class="banner_desc">
              <h2><span>Franck </span> provost</h2>
              <p>{{ t("BANNER_DESCRIPTION") }}</p>
            </div>
          </div>
          <div class="col-md-7">
            <div class="banner" :style="bgBannerStyle"></div>
          </div>
        </div>
      </div>
      <div class="social_list">
        <ul class="list-unstyled list-inline">
          <li>
            <a href="javascript:;"><i class="fab fa-linkedin-in"></i></a>
          </li>
          <li>
            <a href="javascript:;"><i class="fab fa-instagram"></i></a>
          </li>
          <li>
            <a href="javascript:;"><i class="fab fa-twitter"></i></a>
          </li>
          <li>
            <a href="javascript:;"><i class="fab fa-facebook-f"></i></a>
          </li>
        </ul>
      </div>
    </div>
  </header>
  <!-- header end -->
</template>

<script>
import TopBar from "@/components/modules/header/TopBar.vue";
import { store } from "@/stores";
import { useI18n } from "vue-i18n";

export default {
  name: "MainHeader",
  setup() {
    const { t } = useI18n();
    return {
      t,
    };
  },
  components: {
    TopBar,
  },
  data() {
    return {
      store,
      bgBannerStyle: {
        height: store.appdata.catalog.config.bannersize + "px",
        "background-image":
          "url(" +
          store.apiUrl +
          "data7/coiffeur/photos/logos/" +
          store.appdata.catalog.bgbanner +
          ")",
        "background-size": "contain",
      },
    };
  },
};
</script>