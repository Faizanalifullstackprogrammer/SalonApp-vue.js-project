<template>
  <div>
    <!-- search_top -->
    <div class="search_top" :class="[toggleSearch ? 'active_search' : '']">
      <div class="crd-main">
        <div class="close_search" @click="ToggleSearchs">
          <i class="fal fa-times"></i>
        </div>
        <h3 class="m-auto">{{ t("SEARCH") }}</h3>
      </div>
      <div class="crd-body">
        <button
          type="button"
          onclick="event.preventDefault();fselslide(-1);resetticks(true);"
          class="btn btn-prmary"
        >
          <span class="t_reinit">Reset</span>
        </button>
        <div class="header2 csepar" style="display: block"></div>
        <form>
          <div class="form-group">
            <div class="search"><i class="far fa-search"></i></div>
            <input type="text" class="form-control" placeholder="" />
            <button type="button" class="btn btn_ok">OK</button>
          </div>
        </form>
        <p class="mt-2 text-white">
          <span class="t_slides">Slides</span>
          &nbsp;
          <span id="nbphall">{{ this.activeslides }}/37</span>
        </p>
        <div class="col-md-12 text-center">
          <div class="btn-group" role="group" aria-label="Basic example">
            <button
              type="button"
              class="btn btn-prmary"
              @click="ToggleSlides(false)"
            >
              <span class="t_none">No</span>
            </button>
            <button
              type="button"
              class="btn btn-prmary"
              @click="ToggleSlides(true)"
            >
              <span class="t_all">All</span>
            </button>
            <button type="button" class="btn btn-prmary">Okay</button>
          </div>
        </div>
        <ul class="list-unstyled list-inline mt-4 text-white">
          <li>
            <div class="form-check">
              <input
                class="form-check-input"
                type="checkbox"
                value="8"
                v-model="slides"
              /><label class="form-check-label" for="flexCheckDefault"
                >The Living Room ( 8 )</label
              >
            </div>
          </li>
          <li>
            <div class="form-check">
              <input
                class="form-check-input"
                type="checkbox"
                value="6"
                v-model="slides"
              /><label class="form-check-label" for="flexCheckDefault"
                >Women's Cut ( 6 )</label
              >
            </div>
          </li>
          <li>
            <div class="form-check">
              <input
                class="form-check-input"
                type="checkbox"
                value="5"
                v-model="slides"
              /><label class="form-check-label" for="flexCheckDefault"
                >Treatments ( 5 )</label
              >
            </div>
          </li>
          <li>
            <div class="form-check">
              <input
                class="form-check-input"
                type="checkbox"
                value="1"
                v-model="slides"
              /><label class="form-check-label" for="flexCheckDefault"
                >Resume Woman Spring ( 1 )</label
              >
            </div>
          </li>
          <li>
            <div class="form-check">
              <input
                class="form-check-input"
                type="checkbox"
                value="2"
                v-model="slides"
              /><label class="form-check-label" for="flexCheckDefault"
                >Resume Woman Winters ( 2 )</label
              >
            </div>
          </li>
          <li>
            <div class="form-check">
              <input
                class="form-check-input"
                type="checkbox"
                value="11"
                v-model="slides"
              /><label class="form-check-label" for="flexCheckDefault"
                >Massage ( 11 )</label
              >
            </div>
          </li>
        </ul>
      </div>
    </div>
    <!-- search_top end -->
    <!-- list_bars_sidebar -->
    <MenuBar :toggleSidebar="toggleSidebar" v-on:passData="fromChild" />
    <!-- list_bars_sidebar end -->
    <div class="top_list_nav" :style="{ 'background-image': bgheader }">
      <div class="container-fluid">
        <div class="list_bars icon_renew" @click="ToggleSidebar">
          <a href="javascript:;"
            ><i
              class="fas fa-list"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            ></i
          ></a>
        </div>
        <div class="logo">
          <a href="/"><img :src="logo" alt="" class="logos" /></a>
          <div
            class="banner_close"
            :style="{
              background: store.appdata.catalog.config.catalogbgcolor,
            }"
          >
            <a
              href="javascript:;"
              @click="store.toggleHeader = !store.toggleHeader"
              ><i class="fas fa-arrow-alt-up" v-if="store.toggleHeader"></i>
              <i class="fas fa-arrow-alt-down" v-else></i
            ></a>
          </div>
        </div>
        <div class="search_bar icon_renew">
          <a href="javascript:;" @click="store.blob_modal = !store.blob_modal"
            ><i
              class="fas fa-lightbulb-on"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            ></i>
          </a>
          <a
            href="javascript:;"
            data-bs-toggle="modal"
            data-bs-target="#exit_model"
            class="search_slide"
            ><i
              class="fas fa-trash"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            ></i>
          </a>
          <a href="javascript:;" class="search_slide" @click="ToggleSearchs">
            <i
              class="far fa-search"
              :style="{
                background: store.appdata.catalog.config.catalogbgcolor,
              }"
            ></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MenuBar from "@/components/modules/header/MenuBar.vue";
import { store } from "@/stores";
import { useI18n } from "vue-i18n";

export default {
  name: "TopBar",
  setup() {
    const { t } = useI18n();
    return {
      t,
    };
  },
  components: {
    MenuBar,
  },
  data() {
    return {
      toggleSearch: false,
      toggleSidebar: false,
      store,
      bgheader: store.appdata.catalog.bgheader
        ? "url(" +
          store.apiUrl +
          "data7/coiffeur/photos/logos/" +
          store.appdata.catalog.bgheader +
          ")"
        : "url(https://vuejs.org/images/logo.png)",
      logo:
        store.apiUrl +
        "data7/coiffeur/photos/logos/" +
        store.appdata.catalog.logogen,
      slides: [],
      activeslides: 0,
    };
  },
  mounted() {
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        this.toggleSidebar = false;
        this.toggleSearch = false;
      }
    });
  },
  methods: {
    fromChild(data) {
      if (data.methodCall) return this[data.methodCall]();
    },
    ToggleSearchs() {
      this.toggleSearch = !this.toggleSearch;
    },
    ToggleSidebar() {
      this.toggleSidebar = !this.toggleSidebar;
    },
    ToggleSlides(option) {
      if (option) {
        this.slides = [8, 6, 5, 1, 2, 11];
      } else {
        this.slides = [];
        this.activeslides = 0;
      }
      this.ShowSlides();
    },
    ShowSlides() {
      for (let slide in this.slides) {
        console.log(slide);
        this.activeslides += parseInt(this.slides[slide]);
      }
    },
  },
};
</script>

<style>
</style>