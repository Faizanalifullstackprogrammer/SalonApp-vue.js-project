<template>
  <!-- gallery_showcase -->
  <div class="gallery_showcase">
    <vue-easy-lightbox
      :scrollDisabled="false"
      :escDisabled="false"
      :moveDisabled="false"
      :loop="true"
      :visible="visible"
      :imgs="imgs"
      :index="index"
      @hide="handleHide"
    ></vue-easy-lightbox>
    <div class="container">
      <div class="main_heading desc">
        <h3 v-html="store.appdata.catalog.slides[1].params.titleslide"></h3>
        <p>
          There are many variations of passages of Lorem Ipsum available, but
          the majority have suffered alteration in some form, by injected
          humour,
        </p>
      </div>
    </div>
    <Carousel :items-to-show="4" :autoplay="3000" :wrap-around="true">
      <Slide
        v-for="(photo, index) in store.appdata.catalog.slides[1].Photos"
        :key="index"
        class="slide_box galleryslide_width"
      >
        <div class="gallery_thumb">
          <img
            :src="store.apiUrl + 'data7/coiffeur/photos/small/' + photo.name"
            class="h-200 w-261"
            alt=""
          />
        </div>
        <div
          class="gallery_desc"
          :style="{
            background: store.appdata.catalog.config.catalogbgcolor,
          }"
        >
          <h3 v-html="photo.text"></h3>
          <p>
            There are many variations of passages of Lorem Ipsum available, but
            the majority have suffered alteration in some form, by injected
            humour,
          </p>
        </div>
        <div class="plus_icon">
          <a @click="() => showImg(index)"><i class="fal fa-plus"></i></a>
        </div>
      </Slide>
      <template #addons>
        <Pagination class="slick-dots" />
      </template>
    </Carousel>
    <span class="pagingInfo"></span>
  </div>
  <!-- gallery_showcase end -->
</template>

<script>
import { Carousel, Pagination, Slide } from "vue3-carousel";
import { store } from "@/stores";

import "vue3-carousel/dist/carousel.css";

export default {
  name: "SalonGallery",
  components: {
    Carousel,
    Slide,
    Pagination,
  },
  data: () => ({
    store,
    visible: false,
    index: 0, // default: 0
    imgs: [],
  }),
  mounted() {
    for (
      let i = 0;
      i < this.store.appdata.catalog.slides[1].Photos.length;
      i++
    ) {
      this.imgs[i] =
        store.apiUrl +
        "data7/coiffeur/photos/big/" +
        this.store.appdata.catalog.slides[1].Photos[i].name;
    }
  },
  methods: {
    showImg(index) {
      this.index = index;
      this.visible = true;
    },
    handleHide() {
      this.visible = false;
    },
  },
};
</script>

<style>
.gallery_showcase .slide_box .gallery_thumb img {
  object-fit: cover;
}
</style>