<template>
  <!-- le_salon -->
  <div class="le_salon">
    <vue-easy-lightbox
      :scrollDisabled="false"
      :escDisabled="false"
      :moveDisabled="false"
      :loop="true"
      :visible="visible"
      :imgs="imgs"
      :index="index"
      @hide="handleHide"
    ></vue-easy-lightbox>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-7">
          <div class="desc">
            <h3 v-html="store.appdata.catalog.slides[0].params.titleslide"></h3>
            <p>
              There are many variations of passages of Lorem Ipsum available,
              but the majority have suffered alteration in some form, by
              injected humour,
            </p>
          </div>
          <div class="slider_salon">
            <Carousel :items-to-show="3" :autoplay="3000" :wrap-around="true">
              <Slide
                v-for="(photo, index) in store.appdata.catalog.slides[0].photos"
                :key="index"
                @click="() => showImg(index)"
              >
                <div class="col-md-4 carousel__item">
                  <div class="slide_thumb">
                    <div class="box">
                      <div class="play">
                        <a
                          href="javascript:;"
                          v-for="(btn, index) in photo.btns"
                          :key="index"
                          @click="previewAction(btn.url, btn.type)"
                          ><i
                            data-bs-toggle="modal"
                            data-bs-target="#youtub-model-show"
                            class="fab fa-youtube"
                            v-if="btn.type == 'Youtube_TAB'"
                          ></i
                          ><i class="fa fa-link" v-else></i
                        ></a>
                      </div>
                      <img
                        :src="
                          store.apiUrl +
                          'data7/coiffeur/photos/small/' +
                          photo.name
                        "
                        class="h-200"
                        alt=""
                      />
                      <p
                        v-if="photo.postext == 'CC' && photo.rottext == '-45'"
                        :style="{
                          position: 'absolute',
                          top: '50%',
                          left: '50%',
                          transform: 'translate(-50%, -50%)',
                          '-webkit-transform':
                            'translate(-50%, -50%) rotate(-45deg)',
                        }"
                      >
                        <span v-html="photo.text"></span>
                      </p>
                      <p
                        v-if="photo.postext == 'CC' && photo.rottext == '0'"
                        :style="{
                          position: 'absolute',
                          top: '50%',
                          left: '50%',
                          transform: 'translate(-50%, -50%)',
                          '-webkit-transform':
                            'translate(-50%, -50%) rotate(0deg)',
                        }"
                      >
                        <span v-html="photo.text"></span>
                      </p>
                      <p
                        v-if="photo.postext == 'TL' && photo.rottext == '0'"
                        :style="{
                          position: 'absolute',
                          top: '0',
                          left: '0',
                          transform: 'translate(0, 0)',
                          '-webkit-transform': 'translate(0, 0) rotate(0deg)',
                        }"
                      >
                        <span v-html="photo.text"></span>
                      </p>
                    </div>
                    <div class="caption">
                      <span
                        v-for="(legend, index) in photo.legends"
                        :key="index"
                        v-html="legend.legend"
                      ></span>
                    </div>
                  </div>
                </div>
              </Slide>
              <template #addons>
                <Pagination class="slick-dots" />
              </template>
            </Carousel>
          </div>
        </div>
        <div class="col-md-5">
          <div class="side_banner">
            <img src="/images/lesalon_banner.jpg" class="img-fluid" alt="" />
            <p>There are many variations of passages <strong>$200</strong></p>
          </div>
        </div>
      </div>
    </div>
    <div class="bag_image">
      <img src="/images/bag.png" alt="" />
    </div>
  </div>
  <!-- end le_salon -->
</template>
<script>
import { Carousel, Pagination, Slide } from "vue3-carousel";
import { store } from "@/stores";

import "vue3-carousel/dist/carousel.css";

export default {
  name: "LeSalon",
  components: {
    Carousel,
    Slide,
    Pagination,
  },
  data: () => ({
    store,
    visible: false,
    index: 0, // default: 0
    imgs: [],
  }),
  mounted() {
    for (
      let i = 0;
      i < this.store.appdata.catalog.slides[0].photos.length;
      i++
    ) {
      this.imgs[i] =
        store.apiUrl +
        "data7/coiffeur/photos/big/" +
        this.store.appdata.catalog.slides[0].photos[i].name;
    }
  },
  methods: {
    previewAction(url, type) {
      if (type == "Youtube_TAB") {
        store.activeYoutub = url;
      } else {
        window.open(url, "_blank");
      }
    },
    showImg(index) {
      this.index = index;
      this.visible = true;
    },
    handleHide() {
      this.visible = false;
    },
  },
};
</script>
<style scoped>
.carousel__slide {
  align-items: center;
  padding: 0 8px;
  float: left;
  height: 100%;
  min-height: 1px;
}
.col-md-4.carousel__item {
  width: 100%;
}
.caption {
  background: #f8f9fa;
  display: grid;
  text-align: center;
}
</style>
<style>
.carousel__pagination-button--active {
  width: 15px !important;
  height: 15px !important;
  background-color: #b9933e !important;
}
</style>