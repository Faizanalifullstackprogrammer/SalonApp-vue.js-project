import "bootstrap/dist/css/bootstrap.min.css"
import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import i18n from './i18n.js';
import "bootstrap/dist/js/bootstrap.min.js"
import VueEasyLightbox from 'vue-easy-lightbox'
// use beforeEach route guard to set the language
router.beforeEach((to, from, next) => {

    // use the language from the routing param or default language
    let language = to.params.lang;
    console.log(language);
    if (!language) {
        language = 'en'
    }

    // set the current language for i18n.
    i18n.global.locale.value = language
    next()
    })

const app = createApp(App);

app.use(router);
app.use(i18n);
app.use(VueEasyLightbox)
app.mount("#app");
