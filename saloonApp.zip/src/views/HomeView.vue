<script>
import MainHeader from "@/components/modules/header/MainHeader.vue";
import ModalsComponent from "@/components/common/ModalsComponent.vue";
import YoutubModal from "@/components/common/YoutubModal.vue";
import LeSalon from "@/components/LeSalon.vue";
import SalonGallery from "@/components/SalonGallery.vue";
import SalonSliderThree from "@/components/SalonSliderThree.vue";
import FooterComponent from "@/components/common/FooterComponent.vue";
import LoadingComponent from "@/components/common/LoadingComponent.vue";

import { store } from "@/stores";

export default {
  name: "HomePage",
  components: {
    MainHeader,
    ModalsComponent,
    YoutubModal,
    LeSalon,
    SalonGallery,
    FooterComponent,
    LoadingComponent,
    SalonSliderThree,
  },
  data() {
    return {
      store,
      accentColor: "green",
    };
  },
  methods: {},
  mounted() {
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      // body: JSON.stringify({ title: "Vue POST Request Example" })
      cache: "no-cache",
    };
    fetch(store.apiEndpoint, requestOptions)
      .then((response) => response.json())
      .then((data) => {
        store.appdata = JSON.parse(data.response);
        store.isdataLoad = true;
      });
  },
};
</script>

<template>
  <main>
    <span v-if="store.isdataLoad">
      <MainHeader />
      <LeSalon />
      <SalonGallery />
      <SalonSliderThree />
      <FooterComponent />
      <ModalsComponent />
      <YoutubModal />
    </span>
    <span v-else>
      <LoadingComponent />
    </span>
  </main>
</template>
<style>
a {
  text-decoration: none !important;
}
</style>