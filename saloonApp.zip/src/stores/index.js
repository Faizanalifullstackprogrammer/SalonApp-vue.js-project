import { reactive } from 'vue'

export const store = reactive({
  isdataLoad: false,
  toggleHeader:false,
  apiEndpoint:'https://riekerportal.ca/Dev/api/ahs_test',
  apiUrl:'https://www.mobislide.fr/',
  dev:'data7',
  prod:'data7',
  appdata:'',
  activeYoutub:'',
  blob_modal:false
})