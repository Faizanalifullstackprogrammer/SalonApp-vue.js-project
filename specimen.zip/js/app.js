"use strict";

jQuery('.salon_view_slide').slick({
    dots: true,
    arrows: false,
    infinite: true,
    slidesToShow: 3,
    autoplay: false,
    slidesToScroll: 1,

    responsive: [{
        breakpoint: 993,
        settings: {
            dots: false,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1
        }
    }, 

    {
        breakpoint: 768,
        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 2,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 601,
        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 2,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 376,

        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 1,
            slidesToScroll: 1
        }
    }]
}); 


jQuery('.design_slide-view').slick({
    dots: false,
    arrows: false,
    infinite: true,
    slidesToShow: 3,
    autoplay: false,
    slidesToScroll: 1,

    responsive: [{
        breakpoint: 993,
        settings: {
            dots: false,
            infinite: true,
            slidesToShow: 2,
            slidesToScroll: 1
        }
    }, 

    {
        breakpoint: 768,
        settings: {
            dots: false,
            dots: false,
            slidesToShow: 2,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 601,
        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 2,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 376,

        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 1,
            slidesToScroll: 1
        }
    }]
}); 



var $status = $('.pagingInfo');
var $slickElement = $('.gallery_slide');

$slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
  //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
  var i = (currentSlide ? currentSlide : 0) + 1;
  $status.text(i + '/' + slick.slideCount);
});

$slickElement.slick({
   dots: true,
   arrows: false,
   infinite: true,
   slidesToShow: 4.2,
   autoplay: false,
   slidesToScroll: 1,

   responsive: [{
    breakpoint: 993,
    settings: {
        dots: true,
        infinite: true,
        slidesToShow: 3.2,
        slidesToScroll: 1
    }
}, 

{
    breakpoint: 768,
    settings: {
        dots: false,
        arrows: false,
        slidesToShow: 2,
        slidesToScroll: 1
    }

}, 

{
    breakpoint: 601,
    settings: {
        dots: false,
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1
    }

}, 

{
    breakpoint: 376,

    settings: {
        dots: false,
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1
    }
}]
});

jQuery('.face_slider').slick({
    dots: false,
    arrows: false,
    infinite: true,
    slidesToShow: 3,
    rows: 2,
    autoplay: false,
    slidesToScroll: 1,

    responsive: [{
        breakpoint: 993,
        settings: {
            dots: false,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1
        }
    }, 

    {
        breakpoint: 768,
        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 2,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 601,
        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 2,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 376,

        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 1,
            slidesToScroll: 1
        }
    }]
});


jQuery('.face_slider_wrapper').slick({
    dots: true,
    arrows: false,
    infinite: true,
    slidesToShow: 7,
    rows: 2,
    autoplay: false,
    slidesToScroll: 1,

    responsive: [{
        breakpoint: 993,
        settings: {
            dots: false,
            infinite: true,
            slidesToShow: 6,
            slidesToScroll: 1
        }
    }, 

    {
        breakpoint: 768,
        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 5,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 601,
        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 3,
            slidesToScroll: 1
        }

    }, 

    {
        breakpoint: 376,

        settings: {
            dots: false,
            arrows: false,
            slidesToShow: 2,
            slidesToScroll: 1
        }
    }]
});  

$('header .top_list_nav .list_bars').on('click', function(){
    $('header .list_bars_sidebar').toggleClass('active_sidebar');
});

$('.close_sidebar').on('click', function(){
    $('header .list_bars_sidebar').toggleClass('active_sidebar');
});

$('header .list_bars_sidebar .top_detail .edit').on('click', function(){
    $('header .list_bars_sidebar form').toggleClass('active_form');
});

$('header .list_bars_sidebar .top_detail form .close').on('click', function(){
    $('header .list_bars_sidebar form').toggleClass('active_form');
});

$('header .top_list_nav .search_bar .search_slide').on('click', function(){
    $('header .search_top').toggleClass('active_search');
});
$('header .search_top .close_search').on('click', function(){
    $('header .search_top').toggleClass('active_search');
});


$('header .top_list_nav .logo .banner_close').on('click', function(){
    $(this).toggleClass('active');
    $('header .middle_banner').slideToggle( "slow")
});

$('header .list_bars_sidebar .section_list ul li.about_box .about_detail').hide();
$('header .list_bars_sidebar .section_list ul li.about_box').on('click', function(){
    $('header .list_bars_sidebar .section_list ul li.about_box .about_detail').slideToggle( "slow")
});

$('header .list_bars_sidebar .section_list ul li.language_box .language_detail').hide();
$('header .list_bars_sidebar .section_list ul li.language_box').on('click', function(){
    $('header .list_bars_sidebar .section_list ul li.language_box .language_detail').slideToggle( "slow")
});

